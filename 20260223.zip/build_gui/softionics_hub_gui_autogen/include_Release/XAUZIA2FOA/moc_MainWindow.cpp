/****************************************************************************
** Meta object code from reading C++ file 'MainWindow.h'
**
** Created by: The Qt Meta Object Compiler version 69 (Qt 6.10.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../apps/gui/MainWindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MainWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 69
#error "This file was generated using the moc from 6.10.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN10MainWindowE_t {};
} // unnamed namespace

template <> constexpr inline auto MainWindow::qt_create_metaobjectdata<qt_meta_tag_ZN10MainWindowE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "MainWindow",
        "onScanUpdated",
        "",
        "QList<DeviceInfo>",
        "devices",
        "onStatus",
        "text",
        "onConnected",
        "name",
        "addr",
        "onDisconnected",
        "onFrame",
        "t_ns",
        "QList<float>",
        "x",
        "modelValid",
        "modelOut",
        "onStats",
        "ok",
        "bad",
        "onBiasState",
        "hasBias",
        "capturing",
        "onStreamStats",
        "totalSamples",
        "totalTimeSec",
        "last1sSamples",
        "lastDtSec",
        "onDeviceClicked",
        "QListWidgetItem*",
        "item",
        "onAnyControlChanged",
        "applyPipelineNow",
        "onBiasCapture",
        "onBiasSave",
        "onBrowseCsv",
        "onToggleRecord",
        "on",
        "onOpenPositionTracking",
        "onPlotTick",
        "onFftControlsChanged"
    };

    QtMocHelpers::UintData qt_methods {
        // Slot 'onScanUpdated'
        QtMocHelpers::SlotData<void(QVector<DeviceInfo>)>(1, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { 0x80000000 | 3, 4 },
        }}),
        // Slot 'onStatus'
        QtMocHelpers::SlotData<void(QString)>(5, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::QString, 6 },
        }}),
        // Slot 'onConnected'
        QtMocHelpers::SlotData<void(QString, QString)>(7, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::QString, 8 }, { QMetaType::QString, 9 },
        }}),
        // Slot 'onDisconnected'
        QtMocHelpers::SlotData<void()>(10, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onFrame'
        QtMocHelpers::SlotData<void(qulonglong, QVector<float>, bool, float)>(11, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::ULongLong, 12 }, { 0x80000000 | 13, 14 }, { QMetaType::Bool, 15 }, { QMetaType::Float, 16 },
        }}),
        // Slot 'onStats'
        QtMocHelpers::SlotData<void(qulonglong, qulonglong)>(17, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::ULongLong, 18 }, { QMetaType::ULongLong, 19 },
        }}),
        // Slot 'onBiasState'
        QtMocHelpers::SlotData<void(bool, bool)>(20, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Bool, 21 }, { QMetaType::Bool, 22 },
        }}),
        // Slot 'onStreamStats'
        QtMocHelpers::SlotData<void(qulonglong, double, qulonglong, double)>(23, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::ULongLong, 24 }, { QMetaType::Double, 25 }, { QMetaType::ULongLong, 26 }, { QMetaType::Double, 27 },
        }}),
        // Slot 'onDeviceClicked'
        QtMocHelpers::SlotData<void(QListWidgetItem *)>(28, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { 0x80000000 | 29, 30 },
        }}),
        // Slot 'onAnyControlChanged'
        QtMocHelpers::SlotData<void()>(31, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'applyPipelineNow'
        QtMocHelpers::SlotData<void()>(32, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onBiasCapture'
        QtMocHelpers::SlotData<void()>(33, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onBiasSave'
        QtMocHelpers::SlotData<void()>(34, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onBrowseCsv'
        QtMocHelpers::SlotData<void()>(35, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onToggleRecord'
        QtMocHelpers::SlotData<void(bool)>(36, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Bool, 37 },
        }}),
        // Slot 'onOpenPositionTracking'
        QtMocHelpers::SlotData<void()>(38, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onPlotTick'
        QtMocHelpers::SlotData<void()>(39, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onFftControlsChanged'
        QtMocHelpers::SlotData<void()>(40, 2, QMC::AccessPrivate, QMetaType::Void),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<MainWindow, qt_meta_tag_ZN10MainWindowE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10MainWindowE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10MainWindowE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN10MainWindowE_t>.metaTypes,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<MainWindow *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->onScanUpdated((*reinterpret_cast<std::add_pointer_t<QList<DeviceInfo>>>(_a[1]))); break;
        case 1: _t->onStatus((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 2: _t->onConnected((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2]))); break;
        case 3: _t->onDisconnected(); break;
        case 4: _t->onFrame((*reinterpret_cast<std::add_pointer_t<qulonglong>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QList<float>>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<bool>>(_a[3])),(*reinterpret_cast<std::add_pointer_t<float>>(_a[4]))); break;
        case 5: _t->onStats((*reinterpret_cast<std::add_pointer_t<qulonglong>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<qulonglong>>(_a[2]))); break;
        case 6: _t->onBiasState((*reinterpret_cast<std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<bool>>(_a[2]))); break;
        case 7: _t->onStreamStats((*reinterpret_cast<std::add_pointer_t<qulonglong>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<qulonglong>>(_a[3])),(*reinterpret_cast<std::add_pointer_t<double>>(_a[4]))); break;
        case 8: _t->onDeviceClicked((*reinterpret_cast<std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 9: _t->onAnyControlChanged(); break;
        case 10: _t->applyPipelineNow(); break;
        case 11: _t->onBiasCapture(); break;
        case 12: _t->onBiasSave(); break;
        case 13: _t->onBrowseCsv(); break;
        case 14: _t->onToggleRecord((*reinterpret_cast<std::add_pointer_t<bool>>(_a[1]))); break;
        case 15: _t->onOpenPositionTracking(); break;
        case 16: _t->onPlotTick(); break;
        case 17: _t->onFftControlsChanged(); break;
        default: ;
        }
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QList<float> >(); break;
            }
            break;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10MainWindowE_t>.strings))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    }
    return _id;
}
QT_WARNING_POP
