/****************************************************************************
** Meta object code from reading C++ file 'BleWorker.h'
**
** Created by: The Qt Meta Object Compiler version 69 (Qt 6.10.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../apps/gui/BleWorker.h"
#include <QtCore/qmetatype.h>
#include <QtCore/QList>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'BleWorker.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 69
#error "This file was generated using the moc from 6.10.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN9BleWorkerE_t {};
} // unnamed namespace

template <> constexpr inline auto BleWorker::qt_create_metaobjectdata<qt_meta_tag_ZN9BleWorkerE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "BleWorker",
        "scanUpdated",
        "",
        "QList<DeviceInfo>",
        "devices",
        "statusText",
        "text",
        "connected",
        "name",
        "address",
        "disconnected",
        "frameReady",
        "t_ns",
        "QList<float>",
        "x",
        "modelValid",
        "modelOut",
        "statsUpdated",
        "ok",
        "bad",
        "biasStateChanged",
        "hasBias",
        "capturing",
        "streamStats",
        "totalSamples",
        "totalTimeSec",
        "last1sSamples",
        "lastDtSec",
        "startAuto",
        "prefix",
        "connectToIndex",
        "index",
        "disconnectDevice",
        "setInputFormat",
        "fmt",
        "setPipelineConfig",
        "hub::PipelineConfig",
        "cfg",
        "startBiasCapture",
        "frames",
        "startCsv",
        "path",
        "stopCsv",
        "saveBiasCsv",
        "onSerialReadyRead",
        "onSerialError",
        "QSerialPort::SerialPortError",
        "error"
    };

    QtMocHelpers::UintData qt_methods {
        // Signal 'scanUpdated'
        QtMocHelpers::SignalData<void(QVector<DeviceInfo>)>(1, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 3, 4 },
        }}),
        // Signal 'statusText'
        QtMocHelpers::SignalData<void(QString)>(5, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 6 },
        }}),
        // Signal 'connected'
        QtMocHelpers::SignalData<void(QString, QString)>(7, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 8 }, { QMetaType::QString, 9 },
        }}),
        // Signal 'disconnected'
        QtMocHelpers::SignalData<void()>(10, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'frameReady'
        QtMocHelpers::SignalData<void(qulonglong, QVector<float>, bool, float)>(11, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::ULongLong, 12 }, { 0x80000000 | 13, 14 }, { QMetaType::Bool, 15 }, { QMetaType::Float, 16 },
        }}),
        // Signal 'statsUpdated'
        QtMocHelpers::SignalData<void(qulonglong, qulonglong)>(17, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::ULongLong, 18 }, { QMetaType::ULongLong, 19 },
        }}),
        // Signal 'biasStateChanged'
        QtMocHelpers::SignalData<void(bool, bool)>(20, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Bool, 21 }, { QMetaType::Bool, 22 },
        }}),
        // Signal 'streamStats'
        QtMocHelpers::SignalData<void(qulonglong, double, qulonglong, double)>(23, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::ULongLong, 24 }, { QMetaType::Double, 25 }, { QMetaType::ULongLong, 26 }, { QMetaType::Double, 27 },
        }}),
        // Slot 'startAuto'
        QtMocHelpers::SlotData<void(QString)>(28, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 29 },
        }}),
        // Slot 'connectToIndex'
        QtMocHelpers::SlotData<void(int)>(30, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 31 },
        }}),
        // Slot 'disconnectDevice'
        QtMocHelpers::SlotData<void()>(32, 2, QMC::AccessPublic, QMetaType::Void),
        // Slot 'setInputFormat'
        QtMocHelpers::SlotData<void(int)>(33, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 34 },
        }}),
        // Slot 'setPipelineConfig'
        QtMocHelpers::SlotData<void(hub::PipelineConfig)>(35, 2, QMC::AccessPublic, QMetaType::Void, {{
            { 0x80000000 | 36, 37 },
        }}),
        // Slot 'startBiasCapture'
        QtMocHelpers::SlotData<void(int)>(38, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 39 },
        }}),
        // Slot 'startCsv'
        QtMocHelpers::SlotData<void(QString)>(40, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 41 },
        }}),
        // Slot 'stopCsv'
        QtMocHelpers::SlotData<void()>(42, 2, QMC::AccessPublic, QMetaType::Void),
        // Slot 'saveBiasCsv'
        QtMocHelpers::SlotData<void(QString)>(43, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 41 },
        }}),
        // Slot 'onSerialReadyRead'
        QtMocHelpers::SlotData<void()>(44, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onSerialError'
        QtMocHelpers::SlotData<void(QSerialPort::SerialPortError)>(45, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { 0x80000000 | 46, 47 },
        }}),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<BleWorker, qt_meta_tag_ZN9BleWorkerE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject BleWorker::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN9BleWorkerE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN9BleWorkerE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN9BleWorkerE_t>.metaTypes,
    nullptr
} };

void BleWorker::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<BleWorker *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->scanUpdated((*reinterpret_cast<std::add_pointer_t<QList<DeviceInfo>>>(_a[1]))); break;
        case 1: _t->statusText((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 2: _t->connected((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2]))); break;
        case 3: _t->disconnected(); break;
        case 4: _t->frameReady((*reinterpret_cast<std::add_pointer_t<qulonglong>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QList<float>>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<bool>>(_a[3])),(*reinterpret_cast<std::add_pointer_t<float>>(_a[4]))); break;
        case 5: _t->statsUpdated((*reinterpret_cast<std::add_pointer_t<qulonglong>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<qulonglong>>(_a[2]))); break;
        case 6: _t->biasStateChanged((*reinterpret_cast<std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<bool>>(_a[2]))); break;
        case 7: _t->streamStats((*reinterpret_cast<std::add_pointer_t<qulonglong>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<qulonglong>>(_a[3])),(*reinterpret_cast<std::add_pointer_t<double>>(_a[4]))); break;
        case 8: _t->startAuto((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 9: _t->connectToIndex((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 10: _t->disconnectDevice(); break;
        case 11: _t->setInputFormat((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 12: _t->setPipelineConfig((*reinterpret_cast<std::add_pointer_t<hub::PipelineConfig>>(_a[1]))); break;
        case 13: _t->startBiasCapture((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 14: _t->startCsv((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 15: _t->stopCsv(); break;
        case 16: _t->saveBiasCsv((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 17: _t->onSerialReadyRead(); break;
        case 18: _t->onSerialError((*reinterpret_cast<std::add_pointer_t<QSerialPort::SerialPortError>>(_a[1]))); break;
        default: ;
        }
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QList<float> >(); break;
            }
            break;
        }
    }
    if (_c == QMetaObject::IndexOfMethod) {
        if (QtMocHelpers::indexOfMethod<void (BleWorker::*)(QVector<DeviceInfo> )>(_a, &BleWorker::scanUpdated, 0))
            return;
        if (QtMocHelpers::indexOfMethod<void (BleWorker::*)(QString )>(_a, &BleWorker::statusText, 1))
            return;
        if (QtMocHelpers::indexOfMethod<void (BleWorker::*)(QString , QString )>(_a, &BleWorker::connected, 2))
            return;
        if (QtMocHelpers::indexOfMethod<void (BleWorker::*)()>(_a, &BleWorker::disconnected, 3))
            return;
        if (QtMocHelpers::indexOfMethod<void (BleWorker::*)(qulonglong , QVector<float> , bool , float )>(_a, &BleWorker::frameReady, 4))
            return;
        if (QtMocHelpers::indexOfMethod<void (BleWorker::*)(qulonglong , qulonglong )>(_a, &BleWorker::statsUpdated, 5))
            return;
        if (QtMocHelpers::indexOfMethod<void (BleWorker::*)(bool , bool )>(_a, &BleWorker::biasStateChanged, 6))
            return;
        if (QtMocHelpers::indexOfMethod<void (BleWorker::*)(qulonglong , double , qulonglong , double )>(_a, &BleWorker::streamStats, 7))
            return;
    }
}

const QMetaObject *BleWorker::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BleWorker::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN9BleWorkerE_t>.strings))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int BleWorker::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    }
    return _id;
}

// SIGNAL 0
void BleWorker::scanUpdated(QVector<DeviceInfo> _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 0, nullptr, _t1);
}

// SIGNAL 1
void BleWorker::statusText(QString _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 1, nullptr, _t1);
}

// SIGNAL 2
void BleWorker::connected(QString _t1, QString _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 2, nullptr, _t1, _t2);
}

// SIGNAL 3
void BleWorker::disconnected()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void BleWorker::frameReady(qulonglong _t1, QVector<float> _t2, bool _t3, float _t4)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 4, nullptr, _t1, _t2, _t3, _t4);
}

// SIGNAL 5
void BleWorker::statsUpdated(qulonglong _t1, qulonglong _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 5, nullptr, _t1, _t2);
}

// SIGNAL 6
void BleWorker::biasStateChanged(bool _t1, bool _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 6, nullptr, _t1, _t2);
}

// SIGNAL 7
void BleWorker::streamStats(qulonglong _t1, double _t2, qulonglong _t3, double _t4)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 7, nullptr, _t1, _t2, _t3, _t4);
}
QT_WARNING_POP
