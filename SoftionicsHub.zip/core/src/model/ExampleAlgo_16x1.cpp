#include "hub/model/ExampleAlgo_16x1.h"

namespace hub::pt {
HUB_PT_REGISTER_ALGORITHM(ExampleAlgo_16x1)
}
